/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedintest;

import java.util.ArrayList;
/**
 * 1, -2, 3, and 6
 *
 * 4, -1, and 9, but false for 10, 5, and 0
 *
 * @author bradl
 */
public class Driver {

    static ArrayList<NestedInteger> NestedNumberList = new ArrayList<>();

    public static void main(String[] args) {
        reverseDepthSumClass j = new reverseDepthSumClass();
        // Ex #1: construct the list [{1,1},2,{1,1}]
        
        //contstruct {1,1}

        NestedInteger one = new NestedInteger();
        one.add(1);
        one.add(1);
        
        //construct 2
        NestedInteger two = new NestedInteger(2);
        
        //construct {1,1} in a different way
        NestedInteger aOne = new NestedInteger(1);
        NestedInteger bOne = new NestedInteger(1);
        NestedInteger differentOne = new NestedInteger();
        differentOne.add(aOne);
        differentOne.add(bOne);

        //construct entire [{1,1},2,{1,1}] list
        NestedNumberList.add(one);
        NestedNumberList.add(two);
        NestedNumberList.add(differentOne);
        
        int sum = j.reverseDepthSum(NestedNumberList);
        System.out.println(sum);
        
        NestedNumberList = new ArrayList<>();
        j = new reverseDepthSumClass();
        
        //Ex #2: construct the list[{{6},4},1]
        NestedInteger six = new NestedInteger(6);
        NestedInteger four = new NestedInteger(4);
        NestedInteger oneB = new NestedInteger(1);
        oneB.add(four);
        four.add(six);
        NestedNumberList.add(oneB);
        
        int sum2 = j.reverseDepthSum(NestedNumberList);
        System.out.println(sum2);
        
        TwoSumImpl twoSum = new TwoSumImpl();
        twoSum.store(1);
        twoSum.store(-2);
        twoSum.store(3);
        twoSum.store(6);
        
        System.out.println(twoSum.test(4));
        System.out.println(twoSum.test(-1));
        System.out.println(twoSum.test(9));
        System.out.println(twoSum.test(10));
        System.out.println(twoSum.test(5));
        System.out.println(twoSum.test(0));
    }
}
