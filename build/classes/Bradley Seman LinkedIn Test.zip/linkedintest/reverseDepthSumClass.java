/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedintest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 *
 * @author bradl
 */
public class reverseDepthSumClass {

    private int depth = 0;
    private int maxdepth = 0;
    private final HashMap values = new HashMap();

    /**
     *
     * @param input
     * @return
     */
    public int reverseDepthSum(List<NestedInteger> input) {

        constructValueMap(input);
        int sum = 0;
        for (int i = 0; i < values.size(); i++) {
            sum = sum + (int) values.get(i) * (values.size() - i);
        }

        return sum;
    }

    public void constructValueMap(List<NestedInteger> input) {
        for (NestedInteger ni : input) {
            if (ni.getList() != null) {
                depth++;
                if (depth > maxdepth) {
                    maxdepth = depth;
                }
                constructValueMap(ni.getList());
                depth--;
            }
            if (ni.isInteger()) {
                if (values.containsKey(depth)) {
                    Integer operand = (Integer) values.get(depth);
                    values.replace(depth, operand + ni.getInteger());
                } else {
                    values.put(depth, ni.getInteger());
                }
            }
        }
    }
}
